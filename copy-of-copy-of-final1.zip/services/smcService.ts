
import { Time } from 'lightweight-charts';
// FIX: Removed OptimizerParameter from @google/genai import, as it is defined in local types.
import { GoogleGenAI } from "@google/genai";
import { 
    Candle, ChartData, Settings, SMCAnalysisResult, TradeSignal, 
    BacktestResults, ExecutedTrade, SwingPoint, POI, BOS, CHoCH, 
    Drawing, OptimizerSettings, OptimizationResults, OptimizationResultRow, OptimizerParameter
} from '../types';

// --- GEMINI AI INITIALIZATION ---
let ai: GoogleGenAI | null = null;
try {
    // This assumes process.env.API_KEY is available in the execution environment.
    // As per guidelines, the application must not ask the user for the key.
    if (process.env.API_KEY) {
        ai = new GoogleGenAI({apiKey: process.env.API_KEY});
    } else {
        console.warn("Gemini AI API Key is not configured in process.env.API_KEY. AI features will be disabled.");
    }
} catch (e) {
    console.error("Failed to initialize GoogleGenAI:", e);
}


// --- AI RATE LIMITER ---
/**
 * Ensures that calls to a task (like an API request) are spaced out by a minimum interval.
 * This is crucial for avoiding rate limit errors from external services like the Gemini API.
 */
class AiRateLimiter {
    private lastCallTimestamp = 0;
    // Set interval to 7 seconds to stay safely below API rate limits.
    private readonly interval = 7000; // ms between calls

    /**
     * Schedules a task to be executed after ensuring the minimum interval has passed.
     * @param task The async function to execute.
     * @returns A promise that resolves with the result of the task.
     */
    public async schedule<T>(task: () => Promise<T>): Promise<T> {
        const now = Date.now();
        const waitTime = this.lastCallTimestamp + this.interval - now;

        if (waitTime > 0) {
            await new Promise(resolve => setTimeout(resolve, waitTime));
        }

        this.lastCallTimestamp = Date.now();
        return task();
    }
}
const aiRateLimiter = new AiRateLimiter();


const TEHRAN_OFFSET_SECONDS = 3.5 * 60 * 60;

// --- TIME HELPERS ---

export const intervalToSeconds = (interval: string): number => {
    const value = parseInt(interval.slice(0, -1), 10);
    if (isNaN(value)) return 60; // Default to 1m
    const unit = interval.slice(-1).toLowerCase();
    switch (unit) {
        case 'm': return value * 60;
        case 'h': return value * 60 * 60;
        case 'd': return value * 24 * 60 * 60;
        default: return value * 60;
    }
};

export const getUTCOffset = (timezone: string): string => {
    try {
        if (timezone === 'Local') {
            const offset = -new Date().getTimezoneOffset();
            const sign = offset >= 0 ? '+' : '-';
            const hours = Math.floor(Math.abs(offset) / 60).toString().padStart(2, '0');
            const minutes = (Math.abs(offset) % 60).toString().padStart(2, '0');
            return `${sign}${hours}:${minutes}`;
        }
        const now = new Date();
        const formatter = new Intl.DateTimeFormat('en', { timeZone: timezone, timeZoneName: 'shortOffset' });
        const parts = formatter.formatToParts(now);
        const gmtPart = parts.find(part => part.type === 'timeZoneName');
        return gmtPart ? gmtPart.value.replace('GMT', '') : '';
    } catch (e) {
        console.error(`Could not get offset for ${timezone}`, e);
        return '';
    }
};

export const formatSignalTimestamp = (unixTimestamp: any, timezone: string): string => {
    if (!unixTimestamp) return 'N/A';
    const date = new Date((unixTimestamp as number) * 1000);
    const options: Intl.DateTimeFormatOptions = {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    };
    if (timezone !== 'Local') {
        options.timeZone = timezone;
    }
    return new Intl.DateTimeFormat('sv-SE', options).format(date);
};


// --- TELEGRAM SERVICE ---

/**
 * Sends a notification message to a specified Telegram chat.
 * @param message The text message to send.
 * @param token The Telegram bot token.
 * @param chatId The target chat ID.
 * @param useHtml Whether to parse the message as HTML. Defaults to false (plain text).
 * @returns A promise that resolves to an object indicating success or failure.
 */
export async function sendTelegramNotification(
    message: string, 
    token: string, 
    chatId: string,
    useHtml: boolean = false
): Promise<{ success: boolean; description?: string }> {
    if (!token || !chatId) {
        return { success: false, description: "Token or Chat ID is missing." };
    }

    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    const payload: Record<string, any> = {
        chat_id: chatId,
        text: message,
    };
    
    if (useHtml) {
        payload.parse_mode = 'HTML';
    }

    try {
        const response = await fetch(url, { 
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        const data = await response.json();

        if (data.ok) {
            return { success: true };
        } else {
            // Log the full stringified error for better debugging
            console.error("Telegram API Error:", JSON.stringify(data, null, 2));
            return { success: false, description: data.description };
        }
    } catch (error) {
        console.error("Network error sending Telegram message:", error);
        return { success: false, description: "Network error occurred." };
    }
}

/**
 * Formats and sends a trade result notification to Telegram.
 * @param trade The executed trade that has just closed.
 * @param settings The application settings containing Telegram config.
 */
export async function sendTradeResultNotification(
    trade: ExecutedTrade,
    settings: Settings,
): Promise<{ success: boolean; description?: string }> {
    if (!settings.telegramEnabled || !settings.telegramToken || !settings.telegramChatId) {
        return { success: false, description: "Telegram is not enabled or configured." };
    }

    const {
        type,
        outcome,
        entryPrice,
        exitPrice,
        pnl,
        returnOnEquityPercent,
    } = trade;
    
    const outcomeEmoji = outcome === 'Win' ? '✅' : '❌';
    const outcomeText = outcome === 'Win' ? 'WIN' : 'LOSS';
    const tz = settings.timezone;

    const exitTimeFormatted = trade.exitTime ? formatSignalTimestamp(trade.exitTime, tz) : 'N/A';
    
    const message = `
<b>${outcomeEmoji} Trade Closed: ${settings.symbol} ${outcomeText} ${outcomeEmoji}</b>
<b>Direction:</b> ${type}
<b>Outcome:</b> ${outcome}
<b>Entry Price:</b> ${entryPrice.toFixed(4)}
<b>Exit Price:</b> ${exitPrice?.toFixed(4) ?? 'N/A'}
<b>Exit Time:</b> ${exitTimeFormatted}
<b>PnL:</b> $${pnl.toFixed(2)} (${returnOnEquityPercent.toFixed(2)}%)
`.trim().replace(/^\s+/gm, '');

    return sendTelegramNotification(
        message,
        settings.telegramToken,
        settings.telegramChatId,
        true
    );
}

// --- DISCORD SERVICE ---
let discordRateLimitUntil = 0;

/**
 * Sends a notification payload to a specified Discord webhook.
 * @param webhookUrl The Discord webhook URL.
 * @param payload The Discord webhook payload object (e.g., with embeds).
 * @returns A promise that resolves to an object indicating success or failure.
 */
export async function sendDiscordNotification(
    webhookUrl: string,
    payload: object
): Promise<{ success: boolean; description?: string }> {
    if (!webhookUrl) {
        return { success: false, description: "Discord Webhook URL is missing." };
    }

    if (Date.now() < discordRateLimitUntil) {
        const waitSeconds = ((discordRateLimitUntil - Date.now()) / 1000).toFixed(1);
        const description = `Being rate limited by Discord. Please wait ${waitSeconds}s.`;
        console.warn(description);
        return { success: false, description };
    }

    try {
        const response = await fetch(webhookUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });

        if (response.ok) {
            return { success: true };
        } else {
            if (response.status === 429) {
                try {
                    const errorData = await response.json();
                    const retryAfter = (errorData.retry_after || 1) * 1000; // seconds to ms, with a default
                    discordRateLimitUntil = Date.now() + retryAfter;
                    const description = `Rate limited by Discord. Retrying after ${retryAfter / 1000}s.`;
                    console.warn("Discord Webhook API Error:", response.status, errorData);
                    return { success: false, description };
                } catch (e) {
                    discordRateLimitUntil = Date.now() + 2000; // Default 2s wait if parsing fails
                    return { success: false, description: `Rate limited by Discord (Error ${response.status}).` };
                }
            }
            const errorText = await response.text();
            console.error("Discord Webhook API Error:", response.status, errorText);
            return { success: false, description: `Error ${response.status}: ${errorText.substring(0, 100)}` };
        }
    } catch (error) {
        console.error("Network error sending Discord message:", error);
        return { success: false, description: "Network error occurred." };
    }
}

/**
 * Formats and sends a new trade signal notification to Discord.
 * @param signal The new trade signal.
 * @param settings The application settings.
 * @param currentEquity The current account equity.
 * @param priceAdjustmentMessage An optional message about price adjustments.
 * @returns A promise resolving to the success status.
 */
export async function sendSignalNotificationToDiscord(
    signal: TradeSignal,
    settings: Settings,
    currentEquity: number,
    priceAdjustmentMessage: string = ''
): Promise<{ success: boolean; description?: string }> {
    if (!settings.discordEnabled || !settings.discordWebhookUrl) {
        return { success: false, description: "Discord is not enabled or configured." };
    }

    const { type, entryPrice, stopLoss, takeProfit, entryTime } = signal;
    const isBullish = type === 'Bullish';
    const color = isBullish ? 3447003 : 15158332; // Blue for bullish, Red for bearish
    const riskAmount = currentEquity * (settings.orderSizePercent / 100);
    const tz = settings.timezone;
    const signalTimeFormatted = formatSignalTimestamp(entryTime, tz);

    // Calculate leverage for notification
    let leverageText = `${settings.leverage}x (Fixed)`;
    if (settings.leverageType === 'dynamic') {
        const riskPerUnit = Math.abs(entryPrice - stopLoss);
        if (riskPerUnit > 0) {
            const positionSizeInUnits = riskAmount / riskPerUnit;
            const positionValue = positionSizeInUnits * entryPrice;
            const effectiveLeverage = currentEquity > 0 ? positionValue / currentEquity : 0;
            leverageText = `~${Math.ceil(effectiveLeverage)}x (Effective)`;
        }
    }

    const embed = {
        color: color,
        title: `Copy of final1 🔔 New Signal: ${settings.symbol}`,
        fields: [
            { name: 'Direction', value: type, inline: true },
            { name: 'Entry Time', value: signalTimeFormatted, inline: true },
            { name: 'Leverage', value: leverageText, inline: true },
            { name: 'Risk', value: `$${riskAmount.toFixed(2)}`, inline: true },
            { name: 'Entry Price', value: `\`${entryPrice.toFixed(4)}\``, inline: true },
            { name: 'Stop Loss', value: `\`${stopLoss.toFixed(4)}\``, inline: true },
            { name: 'Take Profit', value: `\`${takeProfit.toFixed(4)}\``, inline: true },
        ],
        description: priceAdjustmentMessage.replace(/<i>|<\/i>|\n/g, ''), // Clean HTML for Discord
        timestamp: new Date().toISOString(),
        footer: { text: 'SMC Multi-Timeframe Bot' }
    };

    const payload = {
        username: "SMC Signal Bot",
        embeds: [embed]
    };

    return sendDiscordNotification(settings.discordWebhookUrl, payload);
}

/**
 * Formats and sends a new trade signal notification to Telegram.
 * @param signal The new trade signal.
 * @param settings The application settings.
 * @param currentEquity The current account equity.
 * @param priceAdjustmentMessage An optional message about price adjustments.
 * @returns A promise resolving to the success status.
 */
export async function sendSignalNotificationToTelegram(
    signal: TradeSignal,
    settings: Settings,
    currentEquity: number,
    priceAdjustmentMessage: string = ''
): Promise<{ success: boolean; description?: string }> {
    if (!settings.telegramEnabled || !settings.telegramToken || !settings.telegramChatId) {
        return { success: false, description: "Telegram is not enabled or configured." };
    }

    const { type, entryPrice, stopLoss, takeProfit, entryTime } = signal;
    const isBullish = type === 'Bullish';
    const directionEmoji = isBullish ? '⬆️' : '⬇️';
    const riskAmount = currentEquity * (settings.orderSizePercent / 100);
    const tz = settings.timezone;
    const signalTimeFormatted = formatSignalTimestamp(entryTime, tz);

    // Calculate leverage for notification
    let leverageText = `${settings.leverage}x (Fixed)`;
    if (settings.leverageType === 'dynamic') {
        const riskPerUnit = Math.abs(entryPrice - stopLoss);
        if (riskPerUnit > 0) {
            const positionSizeInUnits = riskAmount / riskPerUnit;
            const positionValue = positionSizeInUnits * entryPrice;
            const effectiveLeverage = currentEquity > 0 ? positionValue / currentEquity : 0;
            leverageText = `~${Math.ceil(effectiveLeverage)}x (Effective)`;
        }
    }

    const message = `
Copy of final1 🔔 <b>New Signal: ${settings.symbol}</b> 🔔
<b>Direction:</b> ${type} ${directionEmoji}
<b>Entry Time:</b> ${signalTimeFormatted}
<b>Leverage:</b> ${leverageText}
<b>Risk:</b> $${riskAmount.toFixed(2)}
<b>Entry Price:</b> <code>${entryPrice.toFixed(4)}</code>
<b>Stop Loss:</b> <code>${stopLoss.toFixed(4)}</code>
<b>Take Profit:</b> <code>${takeProfit.toFixed(4)}</code>
${priceAdjustmentMessage}
`.trim().replace(/^\s+/gm, '');

    return sendTelegramNotification(
        message,
        settings.telegramToken,
        settings.telegramChatId,
        true // Use HTML parsing
    );
}

/**
 * Formats and sends a trade result notification to Discord.
 * @param trade The executed trade that has just closed.
 * @param settings The application settings containing Discord config.
 */
export async function sendTradeResultNotificationToDiscord(
    trade: ExecutedTrade,
    settings: Settings,
): Promise<{ success: boolean; description?: string }> {
    if (!settings.discordEnabled || !settings.discordWebhookUrl) {
        return { success: false, description: "Discord is not enabled or configured." };
    }

    const { type, outcome, entryPrice, exitPrice, pnl, returnOnEquityPercent, leverage } = trade;
    const isWin = outcome === 'Win';
    const outcomeEmoji = isWin ? '✅' : '❌';
    const color = isWin ? 5763719 : 15548997; // Green for win, dark red for loss

    const tz = settings.timezone;
    const exitTimeFormatted = trade.exitTime ? formatSignalTimestamp(trade.exitTime, tz) : 'N/A';
    
    const embed = {
        color: color,
        title: `${outcomeEmoji} Trade Closed: ${settings.symbol} ${outcome}`,
        fields: [
            { name: 'Direction', value: type, inline: true },
            { name: 'Outcome', value: outcome, inline: true },
            { name: 'Leverage', value: `${leverage}x`, inline: true },
            { name: 'PnL', value: `$${pnl.toFixed(2)} (${returnOnEquityPercent.toFixed(2)}%)`, inline: true },
            { name: 'Entry Price', value: `\`${entryPrice.toFixed(4)}\``, inline: true },
            { name: 'Exit Price', value: `\`${exitPrice?.toFixed(4) ?? 'N/A'}\``, inline: true },
            { name: 'Exit Time', value: exitTimeFormatted, inline: true },
        ],
        timestamp: new Date().toISOString(),
        footer: { text: 'SMC Result Bot' }
    };
    
    const payload = {
        username: "SMC Result Bot",
        embeds: [embed]
    };
    
    return sendDiscordNotification(settings.discordWebhookUrl, payload);
}

// --- NOTIFICATION BROADCASTERS ---

/**
 * Sends notifications for a new signal to all enabled platforms.
 */
export async function broadcastNewSignal(
    signal: TradeSignal,
    settings: Settings,
    currentEquity: number,
    priceAdjustmentMessage: string
) {
    const promises = [];
    if (settings.telegramEnabled) {
        promises.push(sendSignalNotificationToTelegram(signal, settings, currentEquity, priceAdjustmentMessage));
    }
    if (settings.discordEnabled) {
        promises.push(sendSignalNotificationToDiscord(signal, settings, currentEquity, priceAdjustmentMessage));
    }
    await Promise.all(promises).catch(err => {
        console.error("Error broadcasting new signal:", err);
    });
}

/**
 * Sends notifications for a closed trade to all enabled platforms.
 */
export async function broadcastTradeResult(trade: ExecutedTrade, settings: Settings) {
    const promises = [];
    if (settings.telegramEnabled) {
        promises.push(sendTradeResultNotification(trade, settings));
    }
    if (settings.discordEnabled) {
        promises.push(sendTradeResultNotificationToDiscord(trade, settings));
    }
    await Promise.all(promises).catch(err => {
        console.error("Error broadcasting trade result:", err);
    });
}


// --- DATA FETCHING ---

async function internalFetchWithProxy(url: string, useProxy: boolean, dataSource: string) {
    const shouldProxy = useProxy || ['coinex', 'toobit', 'bitunix'].includes(dataSource);

    if (!shouldProxy) {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`API Error: ${response.statusText} for URL: ${url}`);
        return response.json();
    }
    
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
    const response = await fetch(proxyUrl);
    if (!response.ok) {
        const errorBody = await response.text().catch(() => 'Could not read error body');
        throw new Error(`Proxy Error: ${response.statusText}. URL: ${url}. Body: ${errorBody.substring(0,100)}`);
    }
    
    const data = await response.json();

    if (typeof data.contents !== 'string') {
         console.error("Proxy response did not contain 'contents' string:", data);
         throw new Error(`Invalid response from proxy for URL: ${url}`);
    }
    
    try {
         return JSON.parse(data.contents);
    } catch (e) {
        console.error("Failed to parse proxied content:", data.contents);
        throw new Error(`Invalid JSON in proxied content for URL: ${url}. Content: ${data.contents.substring(0, 100)}`);
    }
};

/**
 * Retries a function that returns a promise a specified number of times.
 * @param fn The async function to retry. It should return null on failure to trigger a retry.
 * @param attempts The total number of attempts.
 * @param delay The delay in ms between attempts.
 * @returns The result of the function if successful, or null if all attempts fail.
 */
export async function retry<T>(
    fn: () => Promise<T | null>, 
    attempts: number, 
    delay: number
): Promise<T | null> {
    for (let i = 0; i < attempts; i++) {
        try {
            const result = await fn();
            if (result !== null) {
                return result; // Success
            }
            // If result is null, it's a "soft" failure, so we'll retry.
            console.log(`Attempt ${i + 1}/${attempts} failed (returned null).`);
        } catch (error) {
            console.error(`Attempt ${i + 1}/${attempts} failed with an error:`, error);
        }

        if (i < attempts - 1) {
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    console.error(`All ${attempts} attempts failed.`);
    return null;
}


export async function fetchCurrentPriceCoinEx(symbol: string, useProxy: boolean): Promise<number | null> {
    try {
        const marketSymbol = symbol.toUpperCase().replace(/\.P$/, '');
        const apiUrl = `https://api.coinex.com/v1/market/ticker?market=${marketSymbol}`;
        
        const data = await internalFetchWithProxy(apiUrl, useProxy, 'coinex');

        if (data.code === 0 && data.data && data.data.ticker && data.data.ticker.last) {
            return parseFloat(data.data.ticker.last);
        } else {
            console.error("CoinEx Ticker API Error:", data.message || 'Invalid response format');
            return null;
        }
    } catch (error) {
        console.error(`Failed to fetch current price from CoinEx for ${symbol}:`, error);
        return null;
    }
}

export async function fetchCurrentPriceBinance(symbol: string, useProxy: boolean): Promise<number | null> {
    try {
        const isFutures = symbol.toUpperCase().endsWith('.P');
        const apiSymbol = symbol.toUpperCase().replace('.P', '');
        if (!isFutures) {
            console.warn("Binance price fetch is only configured for futures (.P symbols).");
            return null;
        }
        
        const apiUrl = `https://fapi.binance.com/fapi/v1/ticker/price?symbol=${apiSymbol}`;
        
        const data = await internalFetchWithProxy(apiUrl, useProxy, 'binance');

        if (data && data.price) {
            return parseFloat(data.price);
        } else {
            console.error("Binance Ticker API Error:", data.msg || 'Invalid response format');
            return null;
        }
    } catch (error) {
        console.error(`Failed to fetch current price from Binance for ${symbol}:`, error);
        return null;
    }
}

export async function fetchCurrentPriceToobit(symbol: string, useProxy: boolean): Promise<number | null> {
    try {
        const apiUrl = `https://api.toobit.com/api/v1/ticker/price?symbol=${symbol.toUpperCase()}`;
        const data = await internalFetchWithProxy(apiUrl, useProxy, 'toobit');
        // Toobit's ticker response format might be different, assuming a common format like { price: "..." }
        if (data && data.price) {
            return parseFloat(data.price);
        } else {
            console.error("Toobit Ticker API Error:", data.msg || 'Invalid response format');
            return null;
        }
    } catch (error) {
        console.error(`Failed to fetch current price from Toobit for ${symbol}:`, error);
        return null;
    }
}

export async function fetchCurrentPriceBitunix(symbol: string, useProxy: boolean): Promise<number | null> {
    try {
        const cleanSymbol = symbol.toUpperCase().replace('.P', '');
        const bitunixSymbol = cleanSymbol.replace(/USDT$/, '/USDT');
        // Bitunix ticker endpoint might be different. This is a reasonable guess based on their kline endpoint.
        const apiUrl = `https://api.bitunix.com/api/v1/market/ticker?symbol=${bitunixSymbol}`;
        const data = await internalFetchWithProxy(apiUrl, useProxy, 'bitunix');
        // Assuming a response structure like { code: "0", data: { lastPrice: "..." } }
        if (String(data.code) === '0' && data.data && data.data.lastPrice) {
            return parseFloat(data.data.lastPrice);
        } else {
            console.error("Bitunix Ticker API Error:", data.msg || 'Invalid response format');
            return null;
        }
    } catch (error) {
        console.error(`Failed to fetch current price from Bitunix for ${symbol}:`, error);
        return null;
    }
}

export async function fetchCurrentPrice(
    dataSource: string,
    symbol: string,
    useProxy: boolean
): Promise<number | null> {
    switch (dataSource) {
        case 'binance':
            return fetchCurrentPriceBinance(symbol, useProxy);
        case 'coinex':
            return fetchCurrentPriceCoinEx(symbol, useProxy);
        case 'toobit':
            return fetchCurrentPriceToobit(symbol, useProxy);
        case 'bitunix':
            return fetchCurrentPriceBitunix(symbol, useProxy);
        default:
            console.warn(`Live price fetching not supported for ${dataSource}`);
            return null;
    }
}

export async function fetchCandles(symbol: string, interval: string, startTime: number, dataSource: string, useProxy: boolean, fetchEndTime?: number): Promise<Candle[]> {
    try {
        switch (dataSource) {
            case 'binance': {
                let allCandles: any[] = [];
                let currentStartTime = startTime;
                const endTime = fetchEndTime ?? Date.now();

                const useFuturesApi = symbol.toUpperCase().endsWith('.P');
                const apiSymbol = symbol.toUpperCase().replace('.P', '');
                const apiHost = useFuturesApi ? 'https://fapi.binance.com' : 'https://api.binance.com';
                const apiPath = useFuturesApi ? '/fapi/v1/klines' : '/api/v3/klines';
                const limit = useFuturesApi ? 1500 : 1000; // Futures API allows up to 1500

                while (currentStartTime < endTime) {
                    const apiUrl = `${apiHost}${apiPath}?symbol=${apiSymbol}&interval=${interval}&startTime=${currentStartTime}&limit=${limit}${fetchEndTime ? `&endTime=${fetchEndTime}` : ''}`;
                    const data = await internalFetchWithProxy(apiUrl, useProxy, dataSource);
                    if (!Array.isArray(data) || data.length === 0) break;
                    allCandles = allCandles.concat(data);
                    currentStartTime = data[data.length - 1][0] + 1;
                }
                return allCandles.map(d => ({ time: (d[0] / 1000) as Time, open: parseFloat(d[1]), high: parseFloat(d[2]), low: parseFloat(d[3]), close: parseFloat(d[4]), volume: parseFloat(d[5]) }));
            }
            
            case 'coinex': {
                const marketSymbol = symbol.toUpperCase().replace(/\.P$/, '');
                const coinexInterval = interval.replace('m', 'min').replace('h', 'hour').replace('d', 'day');
                const apiUrl = `https://api.coinex.com/v1/market/kline?market=${marketSymbol}&type=${coinexInterval}&limit=1000`;
                const data = await internalFetchWithProxy(apiUrl, useProxy, dataSource);

                if (data.code !== 0 || !Array.isArray(data.data)) {
                    throw new Error(`CoinEx API Error: ${data.message || 'Invalid response'}`);
                }
                
                return data.data.map((d: any[]) => ({
                    time: Number(d[0]) as Time,
                    open: parseFloat(d[1]),
                    high: parseFloat(d[3]),
                    low: parseFloat(d[4]),
                    close: parseFloat(d[2]),
                    volume: parseFloat(d[5]),
                })).sort((a, b) => (a.time as number) - (b.time as number));
            }
            case 'toobit': {
                const toobitApiUrl = `https://api.toobit.com/api/v1/klines?symbol=${symbol.toUpperCase()}&interval=${interval}&limit=1000`;
                const toobitData = await internalFetchWithProxy(toobitApiUrl, useProxy, dataSource);
                if (!Array.isArray(toobitData)) {
                    throw new Error(`Toobit API Error: Invalid response format`);
                }
                return toobitData.map((d: any[]) => ({
                    time: (d[0] / 1000) as Time,
                    open: parseFloat(d[1]),
                    high: parseFloat(d[2]),
                    low: parseFloat(d[3]),
                    close: parseFloat(d[4]),
                    volume: parseFloat(d[5]),
                })).sort((a, b) => (a.time as number) - (b.time as number));
            }
            case 'bitunix': {
                const cleanSymbol = symbol.toUpperCase().replace('.P', '');
                const bitunixSymbol = cleanSymbol.replace(/USDT$/, '/USDT');
                const bitunixApiUrl = `https://api.bitunix.com/api/v1/market/klines?symbol=${bitunixSymbol}&interval=${interval}&limit=1000`;
                const bitunixData = await internalFetchWithProxy(bitunixApiUrl, useProxy, dataSource);
                if (String(bitunixData.code) !== '0' || !Array.isArray(bitunixData.data)) {
                    throw new Error(`Bitunix API Error: ${bitunixData.msg || 'Invalid response'}`);
                }
                return bitunixData.data.map((d: any[]) => ({
                    time: Number(d[0]) as Time,
                    open: parseFloat(d[1]),
                    high: parseFloat(d[2]),
                    low: parseFloat(d[3]),
                    close: parseFloat(d[4]),
                    volume: parseFloat(d[5]),
                })).sort((a, b) => (a.time as number) - (b.time as number));
            }
            default:
                throw new Error(`Unsupported data source: ${dataSource}`);
        }
    } catch (error) {
        console.error(`Failed to fetch data from ${dataSource}:`, error);
        throw error;
    }
}


export async function fetchAllData(settings: Settings): Promise<ChartData> {
    const startDate = new Date(settings.startDate);
    // Fetch one extra day of data to ensure PDL/PDH is available for the first day of the selected range.
    startDate.setDate(startDate.getDate() - 1);
    startDate.setHours(0, 0, 0, 0);
    const startTime = startDate.getTime();

    const endDate = new Date(settings.endDate);
    endDate.setHours(23, 59, 59, 999);
    const fetchEndTime = endDate.getTime();

    const intervals = {
        htf: settings.htfInterval,
        mtf: settings.mtfInterval,
        ltf: settings.ltfInterval,
    };

    const dataPromises = Object.entries(intervals).map(async ([key, value]) => {
        try {
            const data = await fetchCandles(settings.symbol, value, startTime, settings.dataSource, settings.useProxy, fetchEndTime);
            return { key, status: 'fulfilled', value: data };
        } catch (error) {
            return { key, status: 'rejected', reason: `Failed to fetch ${key.toUpperCase()} (${value})`, interval: value };
        }
    });

    const results = await Promise.all(dataPromises);
    
    const failedFetches = results.filter(r => r.status === 'rejected');
    if (failedFetches.length > 0) {
        const errorDetails = failedFetches.map(f => `${f.key} (${f.interval})`).join(', ');
        throw new Error(`Failed to fetch data for: ${errorDetails}`);
    }

    const chartData: ChartData = { htf: [], mtf: [], ltf: [] };
    results.forEach(result => {
        if (result.status === 'fulfilled') {
            chartData[result.key as keyof ChartData] = result.value.sort((a, b) => (a.time as number) - (b.time as number));
        }
    });

    return chartData;
}


// --- DATA RESAMPLING ---

/**
 * Resamples finer-grained candle data into a larger timeframe.
 * @param baseCandles The sorted array of candles to resample from (e.g., 1-minute data).
 * @param targetIntervalSeconds The target timeframe in seconds (e.g., 300 for 5m).
 * @returns A new array of resampled candles.
 */
export function resampleCandles(baseCandles: Candle[], targetIntervalSeconds: number): Candle[] {
    if (!baseCandles.length || targetIntervalSeconds <= 0) return [];

    const resampledMap = new Map<number, {
        open: number; high: number; low: number; close: number;
        volume: number;
        firstTime: number; lastTime: number;
    }>();

    for (const candle of baseCandles) {
        const candleTime = candle.time as number;
        const groupTime = Math.floor(candleTime / targetIntervalSeconds) * targetIntervalSeconds;

        if (!resampledMap.has(groupTime)) {
            resampledMap.set(groupTime, {
                open: candle.open, high: candle.high, low: candle.low, close: candle.close,
                volume: candle.volume ?? 0,
                firstTime: candleTime, lastTime: candleTime,
            });
        } else {
            const group = resampledMap.get(groupTime)!;
            group.high = Math.max(group.high, candle.high);
            group.low = Math.min(group.low, candle.low);
            group.volume += candle.volume ?? 0;
            if (candleTime > group.lastTime) {
                group.close = candle.close;
                group.lastTime = candleTime;
            }
            if (candleTime < group.firstTime) {
                group.open = candle.open;
                group.firstTime = candleTime;
            }
        }
    }

    const resampledCandles: Candle[] = [];
    for (const [time, group] of resampledMap.entries()) {
        resampledCandles.push({
            time: time as Time,
            open: group.open,
            high: group.high,
            low: group.low,
            close: group.close,
            volume: group.volume,
        });
    }
    
    return resampledCandles.sort((a, b) => (a.time as number) - (b.time as number));
}


// --- SMC ANALYSIS ---

/**
 * Identifies swing points (highs and lows) from candle data without lookahead bias.
 * A swing point is confirmed only after 'lookback' candles have closed on its right side.
 * @param data The candle data to analyze.
 * @param lookback The number of candles to check on each side of a potential swing point.
 * @returns An object containing arrays of confirmed swing highs and lows, including their confirmation time.
 */
function findSwingPoints(data: Candle[], lookback: number): { highs: SwingPoint[], lows: SwingPoint[] } {
    const highs: SwingPoint[] = [];
    const lows: SwingPoint[] = [];

    if (data.length < lookback * 2 + 1) {
        return { highs, lows };
    }

    for (let i = lookback; i < data.length - lookback; i++) {
        const candidate = data[i];
        const confirmationCandle = data[i + lookback];

        let isSwingHigh = true;
        let isSwingLow = true;

        for (let j = 1; j <= lookback; j++) {
            // For a swing high, the candidate must be the highest point in the window.
            if (data[i - j].high > candidate.high || data[i + j].high > candidate.high) {
                isSwingHigh = false;
            }
            // For a swing low, the candidate must be the lowest point in the window.
            if (data[i - j].low < candidate.low || data[i + j].low < candidate.low) {
                isSwingLow = false;
            }
            if (!isSwingHigh && !isSwingLow) {
                break;
            }
        }
        
        // Handle plateaus: Only mark the first candle of a plateau as a swing point.
        if (isSwingHigh) {
            if (i > 0 && data[i - 1].high === candidate.high) {
                isSwingHigh = false;
            }
        }
        if (isSwingLow) {
            if (i > 0 && data[i - 1].low === candidate.low) {
                isSwingLow = false;
            }
        }

        if (isSwingHigh) {
            highs.push({
                time: candidate.time,
                price: candidate.high,
                type: 'high',
                confirmationTime: confirmationCandle.time
            });
        }
        if (isSwingLow) {
            lows.push({
                time: candidate.time,
                price: candidate.low,
                type: 'low',
                confirmationTime: confirmationCandle.time
            });
        }
    }
    return { highs, lows };
}


/**
 * Finds Fair Value Gaps (FVG) or Imbalances in a series of candles.
 * @param candles The candle data to analyze.
 * @returns An array of FVG objects, each with a top, bottom, and time.
 */
function findFVGs(candles: Candle[]): { top: number, bottom: number, time: Time, type: 'Bullish' | 'Bearish' }[] {
    const fvgs = [];
    if (candles.length < 3) return [];

    for (let i = 0; i < candles.length - 2; i++) {
        const first = candles[i];
        const third = candles[i+2];

        // Bullish FVG (gap up)
        if (third.low > first.high) {
            fvgs.push({ top: third.low, bottom: first.high, time: first.time, type: 'Bullish' });
        }
        // Bearish FVG (gap down)
        if (third.high < first.low) {
            fvgs.push({ top: first.low, bottom: third.high, time: first.time, type: 'Bearish' });
        }
    }
    return fvgs;
}

// --- CANDLESTICK PATTERN RECOGNITION (CORRECTED) ---
const isBullishCandle = (c: Candle) => c.close > c.open;
const isBearishCandle = (c: Candle) => c.close < c.open;
const getBody = (c: Candle) => ({ top: Math.max(c.open, c.close), bottom: Math.min(c.open, c.close) });
const getBodySize = (c: Candle) => Math.abs(c.close - c.open);

function isBullishEngulfing(prev: Candle, curr: Candle): boolean {
    return isBearishCandle(prev) && isBullishCandle(curr) &&
           curr.close > prev.open && curr.open < prev.close;
}

function isBearishEngulfing(prev: Candle, curr: Candle): boolean {
    return isBullishCandle(prev) && isBearishCandle(curr) &&
           curr.close < prev.open && curr.open > prev.close;
}

function isHammer(candle: Candle): boolean {
    const bodySize = getBodySize(candle);
    const lowerWick = getBody(candle).bottom - candle.low;
    const upperWick = candle.high - getBody(candle).top;
    return lowerWick > bodySize * 2 && upperWick < bodySize * 0.5;
}

function isShootingStar(candle: Candle): boolean {
    const bodySize = getBodySize(candle);
    const upperWick = candle.high - getBody(candle).top;
    const lowerWick = getBody(candle).bottom - candle.low;
    return upperWick > bodySize * 2 && lowerWick < bodySize * 0.5;
}

function isDoji(candle: Candle): boolean {
    const bodySize = getBodySize(candle);
    const range = candle.high - candle.low;
    return range > 0 && bodySize / range < 0.1;
}

function isInsideBar(prev: Candle, curr: Candle): boolean {
    return curr.high < prev.high && curr.low > prev.low;
}

function isBullishHarami(prev: Candle, curr: Candle): boolean {
    return isBearishCandle(prev) && isBullishCandle(curr) &&
           curr.close < prev.open && curr.open > prev.close;
}

function isBearishHarami(prev: Candle, curr: Candle): boolean {
    return isBullishCandle(prev) && isBearishCandle(curr) &&
           curr.close > prev.open && curr.open < prev.close;
}

function isMorningStar(c1: Candle, c2: Candle, c3: Candle): boolean {
    const firstBody = getBody(c1);
    return isBearishCandle(c1) && getBodySize(c1) > getBodySize(c2) &&
           isBullishCandle(c3) && c3.close > (firstBody.top + firstBody.bottom) / 2;
}

function isEveningStar(c1: Candle, c2: Candle, c3: Candle): boolean {
    const firstBody = getBody(c1);
    return isBullishCandle(c1) && getBodySize(c1) > getBodySize(c2) &&
           isBearishCandle(c3) && c3.close < (firstBody.top + firstBody.bottom) / 2;
}

function isThreeWhiteSoldiers(c1: Candle, c2: Candle, c3: Candle): boolean {
    return isBullishCandle(c1) && isBullishCandle(c2) && isBullishCandle(c3) &&
           c2.close > c1.close && c3.close > c2.close &&
           c2.open > c1.open && c2.open < c1.close &&
           c3.open > c2.open && c3.open < c2.close;
}

function isThreeBlackCrows(c1: Candle, c2: Candle, c3: Candle): boolean {
    return isBearishCandle(c1) && isBearishCandle(c2) && isBearishCandle(c3) &&
           c2.close < c1.close && c3.close < c2.close &&
           c2.open < c1.open && c2.open > c1.close &&
           c3.open < c2.open && c3.open > c2.close;
}

function isTweezerBottom(prev: Candle, curr: Candle): boolean {
    const priceRange = prev.high - prev.low;
    return isBearishCandle(prev) && isBullishCandle(curr) &&
           Math.abs(prev.low - curr.low) < (priceRange * 0.1); // Lows are within 10% of previous candle's range
}

function isTweezerTop(prev: Candle, curr: Candle): boolean {
    const priceRange = prev.high - prev.low;
    return isBullishCandle(prev) && isBearishCandle(curr) &&
           Math.abs(prev.high - curr.high) < (priceRange * 0.1); // Highs are within 10% of previous candle's range
}

function isPiercingLine(prev: Candle, curr: Candle): boolean {
    const prevBody = getBody(prev);
    return isBearishCandle(prev) && isBullishCandle(curr) &&
           curr.open < prev.low &&
           curr.close > (prevBody.top + prevBody.bottom) / 2 &&
           curr.close < prev.open;
}

function isDarkCloudCover(prev: Candle, curr: Candle): boolean {
    const prevBody = getBody(prev);
    return isBullishCandle(prev) && isBearishCandle(curr) &&
           curr.open > prev.high &&
           curr.close < (prevBody.top + prevBody.bottom) / 2 &&
           curr.close > prev.open;
}

/**
 * Checks if a candle at a given index matches any of the specified patterns for a given direction.
 * @param candles The array of candles.
 * @param index The index of the candle to check.
 * @param patterns An array of pattern names (e.g., ['engulfing', 'hammer']).
 * @param direction 'Bullish' or 'Bearish'.
 * @returns True if a valid pattern is found, false otherwise.
 */
function hasCandlestickPattern(
    candles: Candle[], 
    index: number, 
    patterns: string[], 
    direction: 'Bullish' | 'Bearish'
): boolean {
    if (index < 1) return false;
    
    const candle = candles[index];
    const prevCandle = candles[index - 1];
    
    const canCheck3Candle = index >= 2;
    const prevPrevCandle = canCheck3Candle ? candles[index - 2] : null;

    for (const pattern of patterns) {
        if (direction === 'Bullish') {
            if (pattern === 'engulfing' && isBullishEngulfing(prevCandle, candle)) return true;
            if (pattern === 'hammer' && isHammer(candle)) return true;
            if (pattern === 'doji' && isDoji(candle)) return true;
            if (pattern === 'insidebar' && isInsideBar(prevCandle, candle)) return true;
            if (pattern === 'harami' && isBullishHarami(prevCandle, candle)) return true;
            if (pattern === 'tweezer' && isTweezerBottom(prevCandle, candle)) return true;
            if (pattern === 'piercing' && isPiercingLine(prevCandle, candle)) return true;
            if (canCheck3Candle && prevPrevCandle) {
                if (pattern === 'morningstar' && isMorningStar(prevPrevCandle, prevCandle, candle)) return true;
                if (pattern === 'threemethods' && isThreeWhiteSoldiers(prevPrevCandle, prevCandle, candle)) return true;
            }
        } else { // Bearish
            if (pattern === 'engulfing' && isBearishEngulfing(prevCandle, candle)) return true;
            if (pattern === 'hammer' && isShootingStar(candle)) return true;
            if (pattern === 'doji' && isDoji(candle)) return true;
            if (pattern === 'insidebar' && isInsideBar(prevCandle, candle)) return true;
            if (pattern === 'harami' && isBearishHarami(prevCandle, candle)) return true;
            if (pattern === 'tweezer' && isTweezerTop(prevCandle, candle)) return true;
            if (pattern === 'piercing' && isDarkCloudCover(prevCandle, candle)) return true;
            if (canCheck3Candle && prevPrevCandle) {
                if (pattern === 'morningstar' && isEveningStar(prevPrevCandle, prevCandle, candle)) return true;
                if (pattern === 'threemethods' && isThreeBlackCrows(prevPrevCandle, prevCandle, candle)) return true;
            }
        }
    }
    
    return false;
}


// --- INDICATOR CALCULATIONS ---

/**
 * Calculates the Average True Range (ATR) for a series of candles.
 * @param candles The candle data to analyze.
 * @param period The lookback period for ATR calculation (e.g., 14).
 * @returns An array of ATR values, each with a time and value.
 */
function calculateATR(candles: Candle[], period: number): { time: Time, value: number }[] {
    if (candles.length < period) return [];
    
    const atrResult: { time: Time, value: number }[] = [];
    let trueRanges: number[] = [];

    for (let i = 1; i < candles.length; i++) {
        const current = candles[i];
        const prev = candles[i-1];
        const tr = Math.max(
            current.high - current.low,
            Math.abs(current.high - prev.close),
            Math.abs(current.low - prev.close)
        );
        trueRanges.push(tr);
    }
    
    if(trueRanges.length < period) return [];

    let sum = 0;
    for (let i = 0; i < period; i++) {
        sum += trueRanges[i];
    }
    let prevAtr = sum / period;
    
    // The first ATR value corresponds to the candle at index `period` (since we need `period` previous TRs).
    // And `trueRanges` starts from index 1 of `candles`. So the first TR corresponds to candle[1].
    // The first `period` TRs correspond to candles[1]...candles[period]. So the first ATR value is at candle `period`.
    atrResult.push({ time: candles[period].time, value: prevAtr });

    for (let i = period; i < trueRanges.length; i++) {
        const currentAtr = ((prevAtr * (period - 1)) + trueRanges[i]) / period;
        // The candle index is `i + 1` because `trueRanges` is offset by 1.
        atrResult.push({ time: candles[i + 1].time, value: currentAtr });
        prevAtr = currentAtr;
    }

    return atrResult;
}


/**
 * Calculates the Average Directional Index (ADX) for a series of candles.
 * @param candles The candle data to analyze.
 * @param period The lookback period for ADX calculation (e.g., 14).
 * @returns An array of ADX values, each with a time and value.
 */
function calculateADX(candles: Candle[], period: number): { time: Time, value: number }[] {
    if (candles.length < period * 2) return [];

    const trs: number[] = [];
    const plusDMs: number[] = [];
    const minusDMs: number[] = [];

    for (let i = 1; i < candles.length; i++) {
        const current = candles[i];
        const prev = candles[i - 1];

        const tr = Math.max(current.high - current.low, Math.abs(current.high - prev.close), Math.abs(current.low - prev.close));
        trs.push(tr);

        const upMove = current.high - prev.high;
        const downMove = prev.low - current.low;

        plusDMs.push(upMove > downMove && upMove > 0 ? upMove : 0);
        minusDMs.push(downMove > upMove && downMove > 0 ? downMove : 0);
    }
    
    const wildersSmoothing = (data: number[], p: number): number[] => {
        const smoothed: number[] = new Array(data.length - (p - 1));
        if (smoothed.length === 0) return [];
        
        let sum = 0;
        for (let i = 0; i < p; i++) {
            sum += data[i];
        }
        smoothed[0] = sum / p;

        for (let i = p; i < data.length; i++) {
            const smoothedIndex = i - (p - 1);
            smoothed[smoothedIndex] = (smoothed[smoothedIndex - 1] * (p - 1) + data[i]) / p;
        }
        return smoothed;
    };

    const smoothedTRs = wildersSmoothing(trs, period);
    const smoothedPlusDMs = wildersSmoothing(plusDMs, period);
    const smoothedMinusDMs = wildersSmoothing(minusDMs, period);

    const plusDIs: number[] = [];
    const minusDIs: number[] = [];
    for (let i = 0; i < smoothedTRs.length; i++) {
        plusDIs.push(smoothedTRs[i] === 0 ? 0 : 100 * (smoothedPlusDMs[i] / smoothedTRs[i]));
        minusDIs.push(smoothedTRs[i] === 0 ? 0 : 100 * (smoothedMinusDMs[i] / smoothedTRs[i]));
    }
    
    const dxs: number[] = [];
    for (let i = 0; i < plusDIs.length; i++) {
        const diSum = plusDIs[i] + minusDIs[i];
        dxs.push(diSum === 0 ? 0 : 100 * (Math.abs(plusDIs[i] - minusDIs[i]) / diSum));
    }
    
    const adxs = wildersSmoothing(dxs, period);
    
    const adxResult: { time: Time, value: number }[] = [];
    const startCandleIndex = (period) + (period - 1);
    for (let i = 0; i < adxs.length; i++) {
        const candleIndex = startCandleIndex + i;
        if (candleIndex < candles.length) {
             adxResult.push({ time: candles[candleIndex].time, value: adxs[i] });
        }
    }
    return adxResult;
}


// --- NEW HELPER FUNCTIONS ---

/**
 * Calculates the high and low for each day from candle data.
 * @param data The candle data.
 * @returns A map where the key is the date string (YYYY-MM-DD) and value is {high, low}.
 */
function calculateDailyLevels(data: Candle[]): Map<string, { high: number, low: number }> {
    const dailyLevels = new Map<string, { high: number, low: number }>();
    data.forEach(candle => {
        const date = new Date((candle.time as number) * 1000);
        // Use UTC date to avoid timezone issues
        const dateString = date.toISOString().split('T')[0];
        
        if (!dailyLevels.has(dateString)) {
            dailyLevels.set(dateString, { high: candle.high, low: candle.low });
        } else {
            const currentDay = dailyLevels.get(dateString)!;
            currentDay.high = Math.max(currentDay.high, candle.high);
            currentDay.low = Math.min(currentDay.low, candle.low);
        }
    });
    return dailyLevels;
}

/**
 * Calculates the high and low of the Asian trading session for each day.
 * @param data The candle data.
 * @param startTime The start time of the Asian session in "HH:MM" format (UTC).
 * @param endTime The end time of the Asian session in "HH:MM" format (UTC).
 * @returns A map where the key is the date string (YYYY-MM-DD) and value is {high, low}.
 */
function calculateAsianRange(data: Candle[], startTime: string, endTime: string): Map<string, { high: number, low: number }> {
    const asianLevels = new Map<string, { high: number, low: number }>();
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);
    
    const dailyCandles = new Map<string, Candle[]>();
    data.forEach(candle => {
        const date = new Date((candle.time as number) * 1000);
        const dateString = date.toISOString().split('T')[0];
        const hour = date.getUTCHours();
        const minute = date.getUTCMinutes();
        
        const timeInMinutes = hour * 60 + minute;
        const startTimeInMinutes = startHour * 60 + startMinute;
        const endTimeInMinutes = endHour * 60 + endMinute;

        if (timeInMinutes >= startTimeInMinutes && timeInMinutes < endTimeInMinutes) {
            if (!dailyCandles.has(dateString)) dailyCandles.set(dateString, []);
            dailyCandles.get(dateString)!.push(candle);
        }
    });

    for (const [date, candles] of dailyCandles.entries()) {
        if (candles.length > 0) {
            asianLevels.set(date, {
                high: Math.max(...candles.map(c => c.high)),
                low: Math.min(...candles.map(c => c.low))
            });
        }
    }
    return asianLevels;
}

async function getAiStopLoss(
    direction: 'Bullish' | 'Bearish',
    entryPrice: number,
    structurePrice: number,
    htfBias: string,
    atrValue: number,
    symbol: string
): Promise<number | null> {
    if (!ai) {
        console.warn("Gemini AI client not initialized. API_KEY might be missing.");
        return null;
    }

    const isBullish = direction === 'Bullish';
    const prompt = `You are an expert trading analyst specializing in Smart Money Concepts (SMC). Based on the following trade setup for ${symbol}, determine the optimal stop loss price. Your goal is to place the stop loss at a logical level that protects against normal volatility and stop hunts, while still maintaining a reasonable risk-to-reward profile.

Trade Context:
- Direction: ${direction}
- Entry Price: ${entryPrice.toFixed(5)}
- Key Structural Point: A swing ${isBullish ? 'low' : 'high'} is at ${structurePrice.toFixed(5)}.
- Higher Timeframe Bias: ${htfBias}
- Recent Volatility (14-period ATR): ${atrValue.toFixed(5)}
- Setup Event: A liquidity sweep of a key level followed by a break of structure.

Provide ONLY the calculated stop loss price as a single number, without any additional text, explanation, or currency symbols.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        const text = response.text.trim();
        const stopLoss = parseFloat(text);

        if (!isNaN(stopLoss) && isFinite(stopLoss)) {
            return stopLoss;
        } else {
            console.error("Gemini AI returned a non-numeric value for stop loss:", text);
            return null;
        }
    } catch (error) {
        console.error("Error calling Gemini API for stop loss:", error);
        return null;
    }
}

async function getAiTakeProfit(
    direction: 'Bullish' | 'Bearish',
    entryPrice: number,
    stopLoss: number,
    htfBias: string,
    symbol: string
): Promise<number | null> {
    if (!ai) {
        console.warn("Gemini AI client not initialized. API_KEY might be missing.");
        return null;
    }

    const isBullish = direction === 'Bullish';
    const prompt = `You are an expert trading analyst specializing in Smart Money Concepts (SMC). Based on the following trade setup for ${symbol}, determine a logical and high-probability take profit price. Consider key liquidity levels (like opposing swing points) as potential targets.

Trade Context:
- Direction: ${direction}
- Entry Price: ${entryPrice.toFixed(5)}
- Stop Loss Price: ${stopLoss.toFixed(5)}
- Higher Timeframe Bias: ${htfBias}

Your primary goal is to identify the next significant structural point or liquidity pool that the price is likely to target.

Provide ONLY the calculated take profit price as a single number, without any additional text, explanation, or currency symbols.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        const text = response.text.trim();
        const takeProfit = parseFloat(text);

        if (!isNaN(takeProfit) && isFinite(takeProfit)) {
            // Basic sanity check: TP should be in the right direction
            if ((isBullish && takeProfit > entryPrice) || (!isBullish && takeProfit < entryPrice)) {
                return takeProfit;
            } else {
                console.error(`Gemini AI returned an invalid TP price (${takeProfit}) for a ${direction} trade from entry ${entryPrice}.`);
                return null;
            }
        } else {
            console.error("Gemini AI returned a non-numeric value for take profit:", text);
            return null;
        }
    } catch (error) {
        console.error("Error calling Gemini API for take profit:", error);
        return null;
    }
}

async function analyzeSMC_LiquiditySweep(chartData: ChartData, settings: Settings): Promise<SMCAnalysisResult> {
    const { htf, ltf } = chartData;
    const trades: TradeSignal[] = [];
    const drawings: Drawing[] = [];

    if (ltf.length < 20 || htf.length < settings.htfSwingLookback * 2 + 1) return { trades, drawings };

    // --- Pre-computation ---
    const htfSwings = findSwingPoints(htf, settings.htfSwingLookback);
    
    const dailyLevels = settings.usePdlPdhLiquidity ? calculateDailyLevels(ltf) : new Map();
    const asianRangeLevels = settings.useAsianRange ? calculateAsianRange(ltf, settings.asianStartTime, settings.asianEndTime) : new Map();
    const ltfAdxValues = settings.useAdxFilter ? calculateADX(ltf, settings.adxPeriod) : [];
    const ltfAtrValues = (settings.slType === 'atr' || settings.useAiStopLoss) ? calculateATR(ltf, settings.atrPeriod) : [];

    // --- Main Loop ---
    const confirmedHighs: SwingPoint[] = [];
    const confirmedLows: SwingPoint[] = [];

    for (let i = 2; i < ltf.length; i++) {
        const currentCandle = ltf[i];
        const prevCandle = ltf[i - 1];
        const prevPrevCandle = ltf[i - 2];

        // --- Dynamically determine HTF bias at this point in time to avoid lookahead ---
        const htfSwingsUpToNow = {
            highs: htfSwings.highs.filter(h => (h.confirmationTime as number) <= (currentCandle.time as number)),
            lows: htfSwings.lows.filter(l => (l.confirmationTime as number) <= (currentCandle.time as number)),
        };
        
        const lastHighs = htfSwingsUpToNow.highs.slice(-2);
        const lastLows = htfSwingsUpToNow.lows.slice(-2);
        let htfBias: 'Bullish' | 'Bearish' | 'Neutral' = 'Neutral';

        const bullishBOS = lastHighs.length > 1 && lastHighs[1].price > lastHighs[0].price;
        const bearishBOS = lastLows.length > 1 && lastLows[1].price < lastLows[0].price;

        if (bullishBOS && !bearishBOS) {
            htfBias = 'Bullish';
        } else if (!bullishBOS && bearishBOS) {
            htfBias = 'Bearish';
        } else if (bullishBOS && bearishBOS) {
            // If both happened, the most recent one dictates the bias
            if ((lastHighs[1].confirmationTime as number) > (lastLows[1].confirmationTime as number)) {
                htfBias = 'Bullish';
            } else {
                htfBias = 'Bearish';
            }
        }
        
        // --- Find LTF Swings (simple 3-candle pattern) ---
        if (prevCandle.high > currentCandle.high && prevCandle.high > prevPrevCandle.high) {
            confirmedHighs.push({ time: prevCandle.time, price: prevCandle.high, type: 'high', confirmationTime: currentCandle.time });
        }
        if (prevCandle.low < currentCandle.low && prevCandle.low < prevPrevCandle.low) {
            confirmedLows.push({ time: prevCandle.time, price: prevCandle.low, type: 'low', confirmationTime: currentCandle.time });
        }

        // --- Liquidity Sweep Check ---
        // Correctly determine dates based on the current candle to avoid midnight crossover issues.
        const currentCandleDate = new Date((currentCandle.time as number) * 1000);
        const currentDateString = currentCandleDate.toISOString().split('T')[0];
        const prevDayDate = new Date(currentCandleDate);
        prevDayDate.setUTCDate(prevDayDate.getUTCDate() - 1);
        const prevDateString = prevDayDate.toISOString().split('T')[0];
        
        // Check if current time is after Asian session has ended to prevent lookahead bias
        const [endHour, endMinute] = settings.asianEndTime.split(':').map(Number);
        const endTimeInMinutes = endHour * 60 + endMinute;
        const currentHourUTC = currentCandleDate.getUTCHours();
        const currentMinuteUTC = currentCandleDate.getUTCMinutes();
        const currentTimeInMinutesUTC = currentHourUTC * 60 + currentMinuteUTC;
        const isAfterAsianSession = currentTimeInMinutesUTC >= endTimeInMinutes;
        
        const pdl = dailyLevels.get(prevDateString)?.low;
        const pdh = dailyLevels.get(prevDateString)?.high;
        const asianLow = asianRangeLevels.get(currentDateString)?.low;
        const asianHigh = asianRangeLevels.get(currentDateString)?.high;

        const sweep_pdl = pdl && settings.usePdlPdhLiquidity && prevCandle.low < pdl && currentCandle.close > pdl;
        const sweep_asian_low = asianLow && settings.useAsianRange && isAfterAsianSession && prevCandle.low < asianLow && currentCandle.close > asianLow;
        const liquidity_sweep_bull = sweep_pdl || sweep_asian_low;

        const sweep_pdh = pdh && settings.usePdlPdhLiquidity && prevCandle.high > pdh && currentCandle.close < pdh;
        const sweep_asian_high = asianHigh && settings.useAsianRange && isAfterAsianSession && prevCandle.high > asianHigh && currentCandle.close < asianHigh;
        const liquidity_sweep_bear = sweep_pdh || sweep_asian_high;

        // --- BOS Check & Entry Logic ---
        const lastConfirmedHigh = confirmedHighs.length > 0 ? confirmedHighs[confirmedHighs.length - 1] : null;
        const lastConfirmedLow = confirmedLows.length > 0 ? confirmedLows[confirmedLows.length - 1] : null;
        
        const bullish_bos = lastConfirmedHigh && currentCandle.close > lastConfirmedHigh.price;
        const bearish_bos = lastConfirmedLow && currentCandle.close < lastConfirmedLow.price;
        
        if (htfBias === 'Bullish' && liquidity_sweep_bull && bullish_bos) {
            const entryLegCandles = ltf.filter(c => (c.time as number) >= (lastConfirmedLow?.time as number) && (c.time as number) <= (currentCandle.time as number));
            const entryOB = [...entryLegCandles].reverse().find(c => c.open > c.close); // Last down candle before up move

            if (entryOB && lastConfirmedLow) {
                 // --- FILTERS ---
                 if (settings.useVolumeInflowFilter) {
                    const currentVolume = currentCandle.volume ?? 0;
                    if (currentVolume === 0 || i < settings.volumeLookbackPeriod) continue;

                    let totalVolume = 0;
                    for (let j = 1; j <= settings.volumeLookbackPeriod; j++) {
                        totalVolume += ltf[i - j].volume ?? 0;
                    }
                    const avgVolume = totalVolume / settings.volumeLookbackPeriod;
                    if (avgVolume > 0 && currentVolume <= avgVolume * settings.volumeMultiplier) {
                        continue; // Volume not high enough, skip trade
                    }
                 }
                 if (settings.useAdxFilter) {
                    const adxDataPoint = [...ltfAdxValues].reverse().find(adx => (adx.time as number) <= (currentCandle.time as number));
                    if (!adxDataPoint || adxDataPoint.value < settings.adxThreshold) continue;
                 }
                 if (settings.useLtfCandlestickFilter) {
                    if (!hasCandlestickPattern(ltf, i, settings.ltfCandlestickPatterns, 'Bullish')) continue;
                 }
                 if (settings.useLiquiditySweepFvgFilter) {
                     if (prevPrevCandle.high >= currentCandle.low) continue;
                 }
                 // --- END FILTERS ---

                 const entryPrice = entryOB.high;
                 let stopLoss: number;

                if (settings.useAiStopLoss) {
                    const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (currentCandle.time as number));
                    const atrValue = atrDataPoint ? atrDataPoint.value : 0;

                    const aiSl = await aiRateLimiter.schedule(() => 
                        getAiStopLoss('Bullish', entryPrice, lastConfirmedLow.price, htfBias, atrValue, settings.symbol)
                    );
                    
                    if (aiSl !== null && aiSl < entryPrice) {
                        stopLoss = aiSl;
                    } else {
                        console.warn(`[AI SL] Fallback used for Bullish trade. AI returned: ${aiSl}`);
                        stopLoss = lastConfirmedLow.price * (1 - (settings.slBufferPercent / 100));
                    }
                } else {
                    switch (settings.slType) {
                        case 'structure':
                            stopLoss = lastConfirmedLow.price * (1 - (settings.slBufferPercent / 100));
                            break;
                        case 'previous_structure':
                            const previousLow = confirmedLows.length > 1 ? confirmedLows[confirmedLows.length - 2] : lastConfirmedLow;
                            stopLoss = previousLow.price * (1 - (settings.slBufferPercent / 100));
                            break;
                        case 'order_block':
                            stopLoss = entryOB.low * (1 - (settings.slBufferPercent / 100));
                            break;
                        case 'fvg':
                            const fvgsInLeg = findFVGs(entryLegCandles);
                            const lastBullishFvg = fvgsInLeg.filter(f => f.type === 'Bullish').pop();
                            // Fallback to structure low if no FVG is found
                            const fvgSlBase = lastBullishFvg ? lastBullishFvg.bottom : lastConfirmedLow.price;
                            stopLoss = fvgSlBase * (1 - (settings.slBufferPercent / 100));
                            break;
                        case 'atr':
                            const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (currentCandle.time as number));
                            const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                            if (atrValue > 0) {
                                stopLoss = entryPrice - (atrValue * settings.atrMultiplier);
                            } else {
                                // Fallback to fixed SL if ATR is zero to avoid division by zero or invalid risk
                                stopLoss = entryPrice * (1 - (settings.fixedSlValue / 100));
                            }
                            break;
                        case 'fixed':
                        default:
                            stopLoss = entryPrice * (1 - (settings.fixedSlValue / 100));
                            break;
                    }
                }
                 
                 const risk = entryPrice - stopLoss;
                 if (risk > 0) {
                    let takeProfit: number;
                    if (settings.useAiTakeProfit) {
                        const aiTp = await aiRateLimiter.schedule(() => 
                            getAiTakeProfit('Bullish', entryPrice, stopLoss, htfBias, settings.symbol)
                        );
                        if (aiTp !== null) {
                            takeProfit = aiTp;
                        } else {
                            console.warn(`[AI TP] Fallback used for Bullish Liquidity Sweep trade.`);
                            takeProfit = entryPrice + risk * settings.rrRatio;
                        }
                    } else {
                        takeProfit = entryPrice + risk * settings.rrRatio;
                    }
                    trades.push({ type: 'Bullish', entryTime: entryOB.time, triggerTime: currentCandle.time, entryPrice, stopLoss, takeProfit });
                    drawings.push({ type: 'BOS', data: { time: currentCandle.time, price: lastConfirmedHigh.price } });
                 }
            }
        }

        if (htfBias === 'Bearish' && liquidity_sweep_bear && bearish_bos) {
            const entryLegCandles = ltf.filter(c => (c.time as number) >= (lastConfirmedHigh?.time as number) && (c.time as number) <= (currentCandle.time as number));
            const entryOB = [...entryLegCandles].reverse().find(c => c.open < c.close); // Last up candle before down move
            
            if (entryOB && lastConfirmedHigh) {
                 // --- FILTERS ---
                 if (settings.useVolumeInflowFilter) {
                    const currentVolume = currentCandle.volume ?? 0;
                    if (currentVolume === 0 || i < settings.volumeLookbackPeriod) continue;

                    let totalVolume = 0;
                    for (let j = 1; j <= settings.volumeLookbackPeriod; j++) {
                        totalVolume += ltf[i - j].volume ?? 0;
                    }
                    const avgVolume = totalVolume / settings.volumeLookbackPeriod;
                     if (avgVolume > 0 && currentVolume <= avgVolume * settings.volumeMultiplier) {
                        continue; // Volume not high enough, skip trade
                    }
                 }
                 if (settings.useAdxFilter) {
                    const adxDataPoint = [...ltfAtrValues].reverse().find(adx => (adx.time as number) <= (currentCandle.time as number));
                    if (!adxDataPoint || adxDataPoint.value < settings.adxThreshold) continue;
                 }
                 if (settings.useLtfCandlestickFilter) {
                    if (!hasCandlestickPattern(ltf, i, settings.ltfCandlestickPatterns, 'Bearish')) continue;
                 }
                 if (settings.useLiquiditySweepFvgFilter) {
                     if (prevPrevCandle.low <= currentCandle.high) continue;
                 }
                 // --- END FILTERS ---

                 const entryPrice = entryOB.low;
                 let stopLoss: number;
                 
                if (settings.useAiStopLoss) {
                    const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (currentCandle.time as number));
                    const atrValue = atrDataPoint ? atrDataPoint.value : 0;

                    const aiSl = await aiRateLimiter.schedule(() => 
                        getAiStopLoss('Bearish', entryPrice, lastConfirmedHigh.price, htfBias, atrValue, settings.symbol)
                    );

                    if (aiSl !== null && aiSl > entryPrice) {
                        stopLoss = aiSl;
                    } else {
                        console.warn(`[AI SL] Fallback used for Bearish trade. AI returned: ${aiSl}`);
                        stopLoss = lastConfirmedHigh.price * (1 + (settings.slBufferPercent / 100));
                    }
                } else {
                    switch (settings.slType) {
                        case 'structure':
                            stopLoss = lastConfirmedHigh.price * (1 + (settings.slBufferPercent / 100));
                            break;
                        case 'previous_structure':
                            const previousHigh = confirmedHighs.length > 1 ? confirmedHighs[confirmedHighs.length - 2] : lastConfirmedHigh;
                            stopLoss = previousHigh.price * (1 + (settings.slBufferPercent / 100));
                            break;
                        case 'order_block':
                            stopLoss = entryOB.high * (1 + (settings.slBufferPercent / 100));
                            break;
                        case 'fvg':
                            const fvgsInLeg = findFVGs(entryLegCandles);
                            const lastBearishFvg = fvgsInLeg.filter(f => f.type === 'Bearish').pop();
                            // Fallback to structure high if no FVG is found
                            const fvgSlBase = lastBearishFvg ? lastBearishFvg.top : lastConfirmedHigh.price;
                            stopLoss = fvgSlBase * (1 + (settings.slBufferPercent / 100));
                            break;
                        case 'atr':
                            const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (currentCandle.time as number));
                            const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                            if (atrValue > 0) {
                                stopLoss = entryPrice + (atrValue * settings.atrMultiplier);
                            } else {
                                // Fallback to fixed SL if ATR is zero
                                stopLoss = entryPrice * (1 + (settings.fixedSlValue / 100));
                            }
                            break;
                        case 'fixed':
                        default:
                            stopLoss = entryPrice * (1 + (settings.fixedSlValue / 100));
                            break;
                    }
                }

                 const risk = stopLoss - entryPrice;
                 if (risk > 0) {
                     let takeProfit: number;
                    if (settings.useAiTakeProfit) {
                        const aiTp = await aiRateLimiter.schedule(() => 
                            getAiTakeProfit('Bearish', entryPrice, stopLoss, htfBias, settings.symbol)
                        );
                        if (aiTp !== null) {
                            takeProfit = aiTp;
                        } else {
                            console.warn(`[AI TP] Fallback used for Bearish Liquidity Sweep trade.`);
                            takeProfit = entryPrice - risk * settings.rrRatio;
                        }
                    } else {
                        takeProfit = entryPrice - risk * settings.rrRatio;
                    }
                     trades.push({ type: 'Bearish', entryTime: entryOB.time, triggerTime: currentCandle.time, entryPrice, stopLoss, takeProfit });
                     drawings.push({ type: 'BOS', data: { time: currentCandle.time, price: lastConfirmedLow.price } });
                 }
            }
        }
    }
    
    const uniqueTrades = trades.filter((trade, index, self) => 
        index === self.findIndex(t => t.entryTime === trade.entryTime && t.type === trade.type)
    );
    return { trades: uniqueTrades, drawings };
}


export async function analyzeSMC(chartData: ChartData, settings: Settings): Promise<SMCAnalysisResult> {
    if (settings.entryModel === 'liquidity_sweep') {
        return await analyzeSMC_LiquiditySweep(chartData, settings);
    }
    
    // --- Existing logic for 'structure_poi' model ---
    const allTrades: TradeSignal[] = [];
    const allDrawings: Drawing[] = [];
    const { htf, mtf, ltf } = chartData;

    if (htf.length < settings.htfSwingLookback * 2 + 1 || mtf.length < 10 || ltf.length < 10) {
        return { trades: [], drawings: [] };
    }

    const htfSwings = findSwingPoints(htf, settings.htfSwingLookback);
    const htfSwingHighs = htfSwings.highs.sort((a, b) => (a.time as number) - (b.time as number));
    const htfSwingLows = htfSwings.lows.sort((a, b) => (a.time as number) - (b.time as number));
    
    const ltfAdxValues = settings.useAdxFilter ? calculateADX(ltf, settings.adxPeriod) : [];
    const ltfAtrValues = (settings.slType === 'atr' || settings.useAiStopLoss) ? calculateATR(ltf, settings.atrPeriod) : [];

    const potentialPois: (POI & { direction: 'Bullish' | 'Bearish' })[] = [];

    // Bullish Structure Analysis
    for (let i = 1; i < htfSwingHighs.length; i++) {
        const prevHigh = htfSwingHighs[i - 1];
        const currentHigh = htfSwingHighs[i];
        if (currentHigh.price > prevHigh.price) { // Bullish BOS
            const bos: BOS = { time: currentHigh.time, price: prevHigh.price };
            allDrawings.push({ type: 'BOS', data: bos });

            const impulseLowCandle = htfSwings.lows.filter(l => (l.time as number) > (prevHigh.time as number) && (l.time as number) < (currentHigh.time as number)).sort((a, b) => a.price - b.price)[0];
            if (!impulseLowCandle) continue;

            if (settings.useLiquiditySweepFilter) {
                const priorLow = htfSwingLows.filter(l => (l.time as number) < (impulseLowCandle.time as number)).pop();
                if (!priorLow || impulseLowCandle.price >= priorLow.price) continue;
            }

            const structureConfirmationTime = currentHigh.confirmationTime;
            const discountLevel = impulseLowCandle.price + (currentHigh.price - impulseLowCandle.price) * settings.discountZone;
            const mtfCandlesInLeg = mtf.filter(c => (c.time as number) >= (impulseLowCandle.time as number) && (c.time as number) <= (currentHigh.time as number));
            
            const fvgsInLeg = settings.useConfluenceFilter ? findFVGs(mtfCandlesInLeg) : [];

            for (const obCandle of [...mtfCandlesInLeg].reverse()) {
                if (obCandle.open > obCandle.close && obCandle.low < discountLevel) {
                     const obCandleIndex = mtf.findIndex(c => c.time === obCandle.time);
                    if (obCandleIndex < 0) continue;

                    if (settings.useMtfCandlestickFilter) {
                        // Corrected logic: Check for pattern on the candle(s) FOLLOWING the order block.
                        if (obCandleIndex + 1 >= mtf.length || !hasCandlestickPattern(mtf, obCandleIndex + 1, settings.mtfCandlestickPatterns, 'Bullish')) {
                            continue;
                        }
                    }

                    if (settings.useFvgFilter) {
                        if (obCandleIndex < 0 || obCandleIndex + 2 >= mtf.length) continue;
                        const secondCandleAfterOb = mtf[obCandleIndex + 2];
                        if (secondCandleAfterOb.low <= obCandle.high) continue;
                    }
                    
                    if (settings.useConfluenceFilter) {
                        const impulseLegRange = currentHigh.price - impulseLowCandle.price;
                        const proximity = impulseLegRange * settings.confluenceProximityPercent;
                        
                        const fvgsForConfluenceCheck = settings.useFvgFilter
                            ? fvgsInLeg.filter(fvg => fvg.time !== obCandle.time)
                            : fvgsInLeg;
                            
                        const hasConfluence = fvgsForConfluenceCheck.some(fvg => 
                            fvg.type === 'Bullish' &&
                            fvg.bottom <= obCandle.high + proximity && 
                            fvg.top >= obCandle.low - proximity
                        );
                        if (!hasConfluence) continue;
                    }

                    potentialPois.push({ 
                        startTime: obCandle.time, 
                        endTime: currentHigh.time,
                        top: obCandle.high, 
                        bottom: obCandle.low,
                        direction: 'Bullish',
                        confirmationTime: structureConfirmationTime
                    });
                }
            }
        }
    }

    // Bearish Structure Analysis
    for (let i = 1; i < htfSwingLows.length; i++) {
        const prevLow = htfSwingLows[i - 1];
        const currentLow = htfSwingLows[i];
        if (currentLow.price < prevLow.price) { // Bearish BOS
            const bos: BOS = { time: currentLow.time, price: prevLow.price };
            allDrawings.push({ type: 'BOS', data: bos });
    
            const impulseHighCandle = htfSwings.highs.filter(h => (h.time as number) > (prevLow.time as number) && (h.time as number) < (currentLow.time as number)).sort((a, b) => b.price - a.price)[0];
            if (!impulseHighCandle) continue;

            if (settings.useLiquiditySweepFilter) {
                const priorHigh = htfSwingHighs.filter(h => (h.time as number) < (impulseHighCandle.time as number)).pop();
                if (!priorHigh || impulseHighCandle.price <= priorHigh.price) continue;
            }
    
            const structureConfirmationTime = currentLow.confirmationTime;
            const premiumLevel = impulseHighCandle.price - (impulseHighCandle.price - currentLow.price) * settings.discountZone;
            const mtfCandlesInLeg = mtf.filter(c => (c.time as number) >= (impulseHighCandle.time as number) && (c.time as number) <= (currentLow.time as number));
    
            const fvgsInLeg = settings.useConfluenceFilter ? findFVGs(mtfCandlesInLeg) : [];

            for (const obCandle of [...mtfCandlesInLeg].reverse()) {
                if (obCandle.open < obCandle.close && obCandle.high > premiumLevel) {
                    const obCandleIndex = mtf.findIndex(c => c.time === obCandle.time);
                    if (obCandleIndex < 0) continue;

                    if (settings.useMtfCandlestickFilter) {
                        // Corrected logic: Check for pattern on the candle(s) FOLLOWING the order block.
                        if (obCandleIndex + 1 >= mtf.length || !hasCandlestickPattern(mtf, obCandleIndex + 1, settings.mtfCandlestickPatterns, 'Bearish')) {
                            continue;
                        }
                    }

                     if (settings.useFvgFilter) {
                        if (obCandleIndex < 0 || obCandleIndex + 2 >= mtf.length) continue;
                        const secondCandleAfterOb = mtf[obCandleIndex + 2];
                        if (secondCandleAfterOb.high >= obCandle.low) continue;
                    }
                    
                    if (settings.useConfluenceFilter) {
                        const impulseLegRange = impulseHighCandle.price - currentLow.price;
                        const proximity = impulseLegRange * settings.confluenceProximityPercent;

                        const fvgsForConfluenceCheck = settings.useFvgFilter
                            ? fvgsInLeg.filter(fvg => fvg.time !== obCandle.time)
                            : fvgsInLeg;

                        const hasConfluence = fvgsForConfluenceCheck.some(fvg =>
                            fvg.type === 'Bearish' &&
                            fvg.bottom <= obCandle.high + proximity && 
                            fvg.top >= obCandle.low - proximity
                        );
                        if (!hasConfluence) continue;
                    }

                    potentialPois.push({
                        startTime: obCandle.time,
                        endTime: currentLow.time,
                        top: obCandle.high,
                        bottom: obCandle.low,
                        direction: 'Bearish',
                        confirmationTime: structureConfirmationTime
                    });
                }
            }
        }
    }
    
    const uniquePois = [...potentialPois]
        .sort((a, b) => (a.startTime as number) - (b.startTime as number))
        .filter((poi, index, self) => 
            index === self.findIndex(p => p.startTime === poi.startTime && p.top === poi.top && p.bottom === poi.bottom)
        );

    uniquePois.forEach(p => allDrawings.push({ type: 'POI', data: { ...p, endTime: ltf[ltf.length - 1].time } }));


    // --- OPTIMIZED LTF ENTRY LOGIC ---
    // This new logic avoids iterating through every single LTF candle.
    // Instead, it processes each POI and finds its interactions with the LTF chart directly.
    const ltfTimeIndexMap = new Map<Time, number>();
    for(let i=0; i < ltf.length; i++) {
        ltfTimeIndexMap.set(ltf[i].time, i);
    }

    for (const poi of uniquePois) {
        let startIndex = ltfTimeIndexMap.get(poi.confirmationTime) ?? 0;
        
        let entryCandleIndex = -1;
        let isInvalidated = false;

        // Find first entry into POI
        for (let i = startIndex; i < ltf.length; i++) {
            const candle = ltf[i];
            const hasEntered = (poi.direction === 'Bullish' && candle.low <= poi.top) || 
                               (poi.direction === 'Bearish' && candle.high >= poi.bottom);
            
            const hasInvalidated = (poi.direction === 'Bullish' && candle.low < poi.bottom) ||
                                   (poi.direction === 'Bearish' && candle.high > poi.top);

            if (hasInvalidated) {
                isInvalidated = true;
                break;
            }
            if (hasEntered) {
                entryCandleIndex = i;
                break;
            }
        }
        if (isInvalidated || entryCandleIndex === -1) continue;
        
        // Monitor for CHoCH from the entry point
        const monitorSlice = ltf.slice(entryCandleIndex);
        if(monitorSlice.length < settings.ltfChochLookback * 2 + 2) continue;

        let chochFound = false;
        for (let i = settings.ltfChochLookback * 2 + 1; i < monitorSlice.length; i++) {
            const currentLtfCandle = monitorSlice[i];
            
            const hasInvalidated = (poi.direction === 'Bullish' && currentLtfCandle.low < poi.bottom) ||
                               (poi.direction === 'Bearish' && currentLtfCandle.high > poi.top);

            if(hasInvalidated) break;

            const dataForSwingCheck = monitorSlice.slice(0, i);
            const potentialTargets = findSwingPoints(dataForSwingCheck, settings.ltfChochLookback);

            if (poi.direction === 'Bullish') {
                const lastLtfHigh = potentialTargets.highs.pop();
                 if (lastLtfHigh && currentLtfCandle.high > lastLtfHigh.price) { // Bullish CHoCH
                    const choch: CHoCH = { time: currentLtfCandle.time, price: lastLtfHigh.price };
                    allDrawings.push({ type: 'CHoCH', data: choch });

                    const chochLowPoint = findSwingPoints(monitorSlice.slice(0, i + 1), settings.ltfChochLookback).lows.pop();
                    if (!chochLowPoint) continue;

                    const entryLegCandles = monitorSlice.filter(c => (c.time as number) >= (chochLowPoint.time as number) && (c.time as number) <= (choch.time as number));
                    const entryOB = [...entryLegCandles].reverse().find(c => c.open > c.close);
                    
                    if (entryOB) {
                        const currentCandleIndexInMonitorSlice = i;
                        if (settings.useLtfCandlestickFilter) {
                           if (!hasCandlestickPattern(monitorSlice, currentCandleIndexInMonitorSlice, settings.ltfCandlestickPatterns, 'Bullish')) continue;
                        }
                        if (settings.useAdxFilter) {
                            const adxDataPoint = [...ltfAdxValues].reverse().find(adx => (adx.time as number) <= (choch.time as number));
                            if (!adxDataPoint || adxDataPoint.value < settings.adxThreshold) continue;
                        }

                        const entryPrice = entryOB.high;
                        let stopLoss: number;
                        if (settings.useAiStopLoss) {
                             const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (choch.time as number));
                             const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                             const aiSl = await aiRateLimiter.schedule(() => getAiStopLoss('Bullish', entryPrice, chochLowPoint.price, poi.direction, atrValue, settings.symbol));
                             stopLoss = (aiSl !== null && aiSl < entryPrice) ? aiSl : chochLowPoint.price * (1 - (settings.slBufferPercent / 100));
                        } else {
                             switch (settings.slType) {
                                case 'structure': stopLoss = chochLowPoint.price * (1 - (settings.slBufferPercent / 100)); break;
                                case 'previous_structure':
                                    const allLows = findSwingPoints(monitorSlice, settings.ltfChochLookback).lows;
                                    const previousStructureLow = allLows.filter(l => (l.time as number) < (chochLowPoint.time as number)).pop();
                                    stopLoss = (previousStructureLow ? previousStructureLow.price : chochLowPoint.price) * (1 - (settings.slBufferPercent / 100));
                                    break;
                                case 'order_block': stopLoss = entryOB.low * (1 - (settings.slBufferPercent / 100)); break;
                                case 'fvg':
                                     const fvgsInLeg = findFVGs(entryLegCandles);
                                     const fvgSlBase = fvgsInLeg.filter(f => f.type === 'Bullish').pop()?.bottom ?? chochLowPoint.price;
                                     stopLoss = fvgSlBase * (1 - (settings.slBufferPercent / 100));
                                     break;
                                case 'atr':
                                     const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (choch.time as number));
                                     const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                                     stopLoss = atrValue > 0 ? entryPrice - (atrValue * settings.atrMultiplier) : entryPrice * (1 - (settings.fixedSlValue / 100));
                                     break;
                                default: stopLoss = entryPrice * (1 - (settings.fixedSlValue / 100)); break;
                             }
                        }

                        const risk = entryPrice - stopLoss;
                        if (risk > 0) {
                            let takeProfit: number;
                            if(settings.useAiTakeProfit) {
                                const aiTp = await aiRateLimiter.schedule(() => getAiTakeProfit('Bullish', entryPrice, stopLoss, poi.direction, settings.symbol));
                                takeProfit = aiTp ?? (entryPrice + risk * settings.rrRatio);
                            } else {
                                takeProfit = entryPrice + risk * settings.rrRatio;
                            }
                             allTrades.push({ entryTime: entryOB.time, triggerTime: choch.time, entryPrice, stopLoss, takeProfit, type: 'Bullish' });
                        }
                    }
                    chochFound = true;
                }
            } else { // Bearish POI
                const lastLtfLow = potentialTargets.lows.pop();
                if (lastLtfLow && currentLtfCandle.low < lastLtfLow.price) { // Bearish CHoCH
                    const choch: CHoCH = { time: currentLtfCandle.time, price: lastLtfLow.price };
                    allDrawings.push({ type: 'CHoCH', data: choch });

                    const chochHighPoint = findSwingPoints(monitorSlice.slice(0, i + 1), settings.ltfChochLookback).highs.pop();
                    if (!chochHighPoint) continue;

                    const entryLegCandles = monitorSlice.filter(c => (c.time as number) >= (chochHighPoint.time as number) && (c.time as number) <= (choch.time as number));
                    const entryOB = [...entryLegCandles].reverse().find(c => c.open < c.close);

                    if(entryOB) {
                        const currentCandleIndexInMonitorSlice = i;
                         if (settings.useLtfCandlestickFilter) {
                           if (!hasCandlestickPattern(monitorSlice, currentCandleIndexInMonitorSlice, settings.ltfCandlestickPatterns, 'Bearish')) continue;
                        }
                        if (settings.useAdxFilter) {
                            const adxDataPoint = [...ltfAdxValues].reverse().find(adx => (adx.time as number) <= (choch.time as number));
                            if (!adxDataPoint || adxDataPoint.value < settings.adxThreshold) continue;
                        }

                        const entryPrice = entryOB.low;
                        let stopLoss: number;
                        if (settings.useAiStopLoss) {
                            const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (choch.time as number));
                            const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                            const aiSl = await aiRateLimiter.schedule(() => getAiStopLoss('Bearish', entryPrice, chochHighPoint.price, poi.direction, atrValue, settings.symbol));
                            stopLoss = (aiSl !== null && aiSl > entryPrice) ? aiSl : chochHighPoint.price * (1 + (settings.slBufferPercent / 100));
                        } else {
                             switch (settings.slType) {
                                case 'structure': stopLoss = chochHighPoint.price * (1 + (settings.slBufferPercent / 100)); break;
                                case 'previous_structure':
                                     const allHighs = findSwingPoints(monitorSlice, settings.ltfChochLookback).highs;
                                     const previousStructureHigh = allHighs.filter(h => (h.time as number) < (chochHighPoint.time as number)).pop();
                                     stopLoss = (previousStructureHigh ? previousStructureHigh.price : chochHighPoint.price) * (1 + (settings.slBufferPercent / 100));
                                     break;
                                case 'order_block': stopLoss = entryOB.high * (1 + (settings.slBufferPercent / 100)); break;
                                case 'fvg':
                                     const fvgsInLeg = findFVGs(entryLegCandles);
                                     const fvgSlBase = fvgsInLeg.filter(f => f.type === 'Bearish').pop()?.top ?? chochHighPoint.price;
                                     stopLoss = fvgSlBase * (1 + (settings.slBufferPercent / 100));
                                     break;
                                case 'atr':
                                     const atrDataPoint = [...ltfAtrValues].reverse().find(atr => (atr.time as number) <= (choch.time as number));
                                     const atrValue = atrDataPoint ? atrDataPoint.value : 0;
                                     stopLoss = atrValue > 0 ? entryPrice + (atrValue * settings.atrMultiplier) : entryPrice * (1 + (settings.fixedSlValue / 100));
                                     break;
                                default: stopLoss = entryPrice * (1 + (settings.fixedSlValue / 100)); break;
                             }
                        }
                        
                        const risk = stopLoss - entryPrice;
                        if (risk > 0) {
                            let takeProfit: number;
                            if(settings.useAiTakeProfit) {
                                const aiTp = await aiRateLimiter.schedule(() => getAiTakeProfit('Bearish', entryPrice, stopLoss, poi.direction, settings.symbol));
                                takeProfit = aiTp ?? (entryPrice - risk * settings.rrRatio);
                            } else {
                                takeProfit = entryPrice - risk * settings.rrRatio;
                            }
                            allTrades.push({ entryTime: entryOB.time, triggerTime: choch.time, entryPrice, stopLoss, takeProfit, type: 'Bearish' });
                        }
                    }
                    chochFound = true;
                }
            }
            if (chochFound) break;
        }
    }

    allTrades.sort((a, b) => (a.entryTime as number) - (b.entryTime as number));
    const uniqueTrades = allTrades.filter((trade, index, self) => 
        index === self.findIndex(t => t.entryTime === trade.entryTime && t.type === trade.type)
    );
    return { trades: uniqueTrades, drawings: allDrawings };
}

// --- BACKTESTING ---

export function runBacktest(
    ltfData: Candle[], 
    tradeSignals: TradeSignal[], 
    settings: Settings, 
    startingEquity?: number,
    bidAskData?: { ask: Candle[], bid: Candle[] }
): BacktestResults {
    const initialCapitalForRun = startingEquity ?? settings.initialCapital;
    let equity = initialCapitalForRun;
    let peakEquity = initialCapitalForRun;
    let maxDrawdown = 0;
    let maxDrawdownAmount = 0;
    const executedTrades: ExecutedTrade[] = [];
    let activeTrade: ExecutedTrade | null = null;
    let pendingSignals = [...tradeSignals].sort((a, b) => (a.entryTime as number) - (b.entryTime as number));

    let dailyLossCount = 0;
    let consecutiveLossCount = 0;
    let currentDayString = '';
    
    const ltfIntervalSeconds = intervalToSeconds(settings.ltfInterval);

    const useBidAsk = bidAskData && bidAskData.ask.length > 0 && bidAskData.bid.length > 0 && bidAskData.ask.length === bidAskData.bid.length && bidAskData.ask.length === ltfData.length;
    if (bidAskData && !useBidAsk) {
        console.warn("Bid/Ask data provided but it's misaligned or incomplete. Falling back to single-stream backtest.");
    }
    
    const getDayString = (time: Time, timezone: string): string => {
        try {
            const options: Intl.DateTimeFormatOptions = {
                year: 'numeric', month: '2-digit', day: '2-digit',
                timeZone: timezone === 'Local' ? undefined : timezone,
            };
            return new Intl.DateTimeFormat('sv-SE', options).format(new Date((time as number) * 1000));
        } catch (e) {
            console.warn(`Invalid timezone for daily loss counter: "${timezone}". Falling back to UTC.`);
            return new Date((time as number) * 1000).toISOString().split('T')[0];
        }
    };


    for (let i = 0; i < ltfData.length; i++) {
        const candle = ltfData[i];
        const askCandle = useBidAsk ? bidAskData!.ask[i] : candle;
        const bidCandle = useBidAsk ? bidAskData!.bid[i] : candle;
        const candleDayString = getDayString(candle.time, settings.timezone);
        
        // Check for day change. This block now handles both resetting the counter AND invalidating stale signals.
        if (candleDayString !== currentDayString) {
            // If the PREVIOUS day was locked out due to either loss limit...
            const wasLockedOutByDaily = settings.useMaxDailyLossesFilter && dailyLossCount >= settings.maxDailyLosses;
            const wasLockedOutByConsecutive = settings.useMaxConsecutiveLossesFilter && consecutiveLossCount >= settings.maxConsecutiveLosses;
            const wasLockedOut = wasLockedOutByDaily || wasLockedOutByConsecutive;

            if (wasLockedOut) {
                // ...invalidate any remaining signals from that previous day.
                // `currentDayString` still holds the date string of the previous day at this point.
                pendingSignals = pendingSignals.filter(signal => {
                    const signalDayString = getDayString(signal.entryTime, settings.timezone);
                    return signalDayString !== currentDayString;
                });
            }

            // Now, update state for the NEW day.
            currentDayString = candleDayString;
            dailyLossCount = 0;
            consecutiveLossCount = 0; // Reset consecutive losses on a new day
        }

        // 1. Check to close an active trade
        if (activeTrade) {
            let outcome: 'Win' | 'Loss' | null = null;
            let exitPrice: number | null = null;

            const hitSL = activeTrade.type === 'Bullish' ? bidCandle.low <= activeTrade.slPrice : askCandle.high >= activeTrade.slPrice;
            const hitTP = activeTrade.type === 'Bullish' ? bidCandle.high >= activeTrade.tpPrice : askCandle.low <= activeTrade.tpPrice;

            if (hitSL) {
                outcome = 'Loss';
                exitPrice = activeTrade.slPrice;
            } else if (hitTP) {
                outcome = 'Win';
                exitPrice = activeTrade.tpPrice;
            }

            if (outcome && exitPrice) {
                if (outcome === 'Loss') {
                    dailyLossCount++;
                    consecutiveLossCount++;
                } else {
                    consecutiveLossCount = 0; // Reset on win
                }

                const equityBefore = activeTrade.equity;
                const amountToRisk = activeTrade.pnl; // Base risk amount was stored here
                
                const riskPerUnit = Math.abs(activeTrade.entryPrice - activeTrade.slPrice);
                const positionSizeInUnits = riskPerUnit > 0 ? amountToRisk / riskPerUnit : 0;
                
                // PnL calculation must account for spread
                let pnlPerUnit = 0;
                if (activeTrade.type === 'Bullish') {
                    // Closed a long position (sell at BID price)
                    pnlPerUnit = exitPrice - activeTrade.entryPrice;
                } else {
                    // Closed a short position (buy at ASK price)
                    pnlPerUnit = activeTrade.entryPrice - exitPrice;
                }

                const finalPnl = pnlPerUnit * positionSizeInUnits;
                const positionValue = positionSizeInUnits * activeTrade.entryPrice;
                const finalCommissionCost = positionValue * (settings.commissionPercent / 100) * 2;
                const netPnl = finalPnl - finalCommissionCost;

                equity += netPnl;
                if (equity > peakEquity) peakEquity = equity;

                const drawdownPercent = peakEquity > 0 ? ((peakEquity - equity) / peakEquity) * 100 : 0;
                if (drawdownPercent > maxDrawdown) {
                    maxDrawdown = drawdownPercent;
                    maxDrawdownAmount = peakEquity - equity;
                }

                // Update the trade object that's already in the executedTrades array
                activeTrade.outcome = outcome;
                activeTrade.exitTime = candle.time;
                activeTrade.exitPrice = exitPrice;
                activeTrade.pnl = netPnl;
                activeTrade.equity = equity;
                activeTrade.returnOnEquityPercent = (netPnl / equityBefore) * 100;

                activeTrade = null; // Position is now closed
            }
        }

        // 2. Check to open a new trade (only if no active trade)
        if (!activeTrade) {
            // Check if loss limits have been reached FOR THE CURRENT DAY
            if (settings.useMaxDailyLossesFilter && dailyLossCount >= settings.maxDailyLosses) {
                continue; // Skip opening new trades for the rest of this day
            }
             if (settings.useMaxConsecutiveLossesFilter && consecutiveLossCount >= settings.maxConsecutiveLosses) {
                continue; // Skip opening new trades for the rest of this day
            }

            for (let sigIdx = 0; sigIdx < pendingSignals.length; sigIdx++) {
                const signal = pendingSignals[sigIdx];

                // Invalidate signal if it's too old
                const ageInSeconds = (candle.time as number) - (signal.entryTime as number);
                if (typeof signal.entryTime !== 'number') continue;
                const ageInCandles = ageInSeconds / ltfIntervalSeconds;

                if (ageInCandles > settings.maxSignalAgeCandles) {
                    pendingSignals.splice(sigIdx, 1); // Signal is expired
                    sigIdx--;
                    continue;
                }

                if ((candle.time as number) < (signal.entryTime as number)) continue;
                
                // Entry logic accounts for spread
                const isBullishEntry = signal.type === 'Bullish' && askCandle.low <= signal.entryPrice && askCandle.high >= signal.entryPrice;
                const isBearishEntry = signal.type === 'Bearish' && bidCandle.high >= signal.entryPrice && bidCandle.low <= signal.entryPrice;

                if (isBullishEntry || isBearishEntry) {
                    const equityBefore = equity;
                    const amountToRiskForPnl = equityBefore * (settings.orderSizePercent / 100);

                    let appliedLeverage = 0;
                    if (settings.leverageType === 'fixed') {
                        appliedLeverage = settings.leverage;
                    } else { // dynamic
                        const riskPerUnit = Math.abs(signal.entryPrice - signal.stopLoss);
                        if (riskPerUnit > 0) {
                            const positionSizeInUnits = amountToRiskForPnl / riskPerUnit;
                            const positionValue = positionSizeInUnits * signal.entryPrice;
                            const effectiveLeverage = equityBefore > 0 ? positionValue / equityBefore : 0;
                            appliedLeverage = Math.ceil(effectiveLeverage);
                        }
                    }

                    if (settings.filterByCommission) {
                        const riskPerUnit = Math.abs(signal.entryPrice - signal.stopLoss);
                        if (riskPerUnit <= 0) continue;
                        const positionSizeInUnits = amountToRiskForPnl / riskPerUnit;
                        const positionValue = positionSizeInUnits * signal.entryPrice;
                        const commissionCost = positionValue * (settings.commissionPercent / 100) * 2;
                        const potentialProfit = amountToRiskForPnl * settings.rrRatio;
                        if (potentialProfit <= commissionCost) continue;
                    }

                    activeTrade = {
                        signalTime: signal.entryTime,
                        entryTime: candle.time,
                        outcome: 'Open',
                        exitTime: null,
                        exitPrice: null,
                        entryPrice: signal.entryPrice,
                        type: signal.type,
                        pnl: amountToRiskForPnl, // Temporarily store amountToRisk, it will be replaced on close
                        equity: equityBefore, // Store equity at time of entry
                        slPrice: signal.stopLoss,
                        tpPrice: signal.takeProfit,
                        returnOnEquityPercent: 0,
                        leverage: appliedLeverage,
                    };

                    executedTrades.push(activeTrade);
                    pendingSignals.splice(sigIdx, 1);
                    sigIdx--; // Adjust index after splice
                    break; // Only one trade can open per candle
                }
            }
        }
    }

    // Ensure trades are sorted chronologically before calculating final metrics
    executedTrades.sort((a, b) => {
        const timeA = a.entryTime || a.signalTime;
        const timeB = b.entryTime || b.signalTime;
        if (timeA === null) return 1;
        if (timeB === null) return -1;
        return (timeA as number) - (timeB as number);
    });

    const closedTrades = executedTrades.filter(t => t.outcome !== 'Open');
    const totalTrades = closedTrades.length;

    if (totalTrades === 0 && !executedTrades.some(t => t.outcome === 'Open')) {
        return { trades: executedTrades, maxDrawdown: 0, maxDrawdownAmount: 0, netProfitPercent: 0, winRate: 0, profitFactor: 0, finalEquity: equity, totalTrades: 0 };
    }

    const wins = closedTrades.filter(t => t.outcome === 'Win').length;
    const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
    const finalEquity = equity;
    const netProfitPercent = ((finalEquity - initialCapitalForRun) / initialCapitalForRun) * 100;
    const totalWinPnl = closedTrades.filter(t => t.outcome === 'Win').reduce((sum, t) => sum + t.pnl, 0);
    const totalLossPnl = Math.abs(closedTrades.filter(t => t.outcome === 'Loss').reduce((sum, t) => sum + t.pnl, 0));
    const profitFactor = totalLossPnl > 0 ? totalWinPnl / totalLossPnl : Infinity;

    return {
        trades: executedTrades,
        maxDrawdown,
        maxDrawdownAmount,
        netProfitPercent,
        winRate,
        profitFactor,
        finalEquity,
        totalTrades
    };
}


// --- OPTIMIZER ---

function generateCombinations(optimizerSettings: OptimizerSettings, baseSettings: Settings): Partial<Settings>[] {
    const paramsToOptimize: { key: keyof OptimizerSettings, values: number[] }[] = [];

    (Object.keys(optimizerSettings) as Array<keyof OptimizerSettings>).forEach(key => {
        if (key !== 'targetMetric' && optimizerSettings[key].enabled) {
            const param = optimizerSettings[key as keyof typeof optimizerSettings] as OptimizerParameter;
            if (param && param.end >= param.start && param.step > 0) {
                const values: number[] = [];
                for (let i = param.start; i <= param.end; i += param.step) {
                    // Handle floating point inaccuracies
                    const roundedValue = parseFloat(i.toPrecision(10));
                    values.push(roundedValue);
                }
                if (!values.includes(param.end)) { // Ensure end is included if step doesn't land on it
                    if (param.start < param.end && values[values.length - 1] < param.end) {
                       values.push(param.end);
                    }
                }
                paramsToOptimize.push({ key: key as keyof OptimizerSettings, values });
            }
        }
    });

    const combinations: Partial<Settings>[] = [];
    if (paramsToOptimize.length === 0) {
        return [{}]; // Return one run with base settings if nothing to optimize
    }

    const generate = (index: number, currentSettings: Partial<Settings>) => {
        if (index === paramsToOptimize.length) {
            combinations.push(currentSettings);
            return;
        }

        const { key, values } = paramsToOptimize[index];
        for (const value of values) {
            const nextSettings = { ...currentSettings, [key]: value };
            generate(index + 1, nextSettings);
        }
    };

    generate(0, {});
    // FIX: A function whose declared type is neither 'undefined', 'void', nor 'any' must return a value.
    return combinations;
}

// FIX: Export runOptimizer function to be used in App.tsx
export async function runOptimizer(
    chartData: ChartData,
    baseSettings: Settings,
    optimizerSettings: OptimizerSettings
): Promise<OptimizationResults> {
    const combinations = generateCombinations(optimizerSettings, baseSettings);
    const runs: OptimizationResultRow[] = [];

    // To prevent overwhelming the system, we process them serially to avoid crashing the browser tab,
    // which is crucial if AI-based analysis is enabled.
    for (let i = 0; i < combinations.length; i++) {
        const params = combinations[i];
        const settingsForRun = { ...baseSettings, ...params };
        
        const analysis = await analyzeSMC(chartData, settingsForRun);
        const results = runBacktest(chartData.ltf, analysis.trades, settingsForRun);
        
        runs.push({
            id: i,
            params,
            results,
        });
    }

    let bestRun: OptimizationResultRow | null = null;
    if (runs.length > 0) {
        bestRun = runs.reduce((best, current) => {
            const metric = optimizerSettings.targetMetric;
            if (!best) return current;
            // For drawdown, lower is better.
            if (metric === 'maxDrawdown') {
                return (current.results[metric] < best.results[metric]) ? current : best;
            }
            return (current.results[metric] > best.results[metric]) ? current : best;
        }, runs[0]);
    }

    return { runs, bestRun };
}

// FIX: Export order execution functions to be used in App.tsx
// --- ORDER EXECUTION ---

export async function sendOrderToCoinEx(
    signal: TradeSignal,
    settings: Settings,
    equity: number
): Promise<{ success: boolean; description?: string } | null> {
    console.log('Sending order to CoinEx (stub)', { signal, settings, equity });
    if (!settings.coinexAccessId || !settings.coinexSecretKey) {
        return { success: false, description: "CoinEx API keys not set." };
    }
    // Placeholder for actual API call
    await new Promise(res => setTimeout(res, 500));
    return { success: true, description: `[Stub] Successfully placed ${signal.type} order on CoinEx for ${settings.symbol}.` };
}

export async function sendOrderToBinance(
    signal: TradeSignal,
    settings: Settings,
    equity: number
): Promise<{ success: boolean; description?: string } | null> {
    console.log('Sending order to Binance (stub)', { signal, settings, equity });
    if (!settings.binanceAccessId || !settings.binanceSecretKey) {
        return { success: false, description: "Binance API keys not set." };
    }
    // Placeholder for actual API call
    await new Promise(res => setTimeout(res, 500));
    return { success: true, description: `[Stub] Successfully placed ${signal.type} order on Binance for ${settings.symbol}.` };
}
